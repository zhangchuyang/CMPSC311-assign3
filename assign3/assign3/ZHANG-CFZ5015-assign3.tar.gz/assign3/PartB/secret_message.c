#include <secret_message.h>
#include <stdio.h>
#include <stdlib.h>


void secret_message1(){
	printf("This is one secret message\n");
}

void secret_message2(){
	printf("This is another secret message\n");
}
